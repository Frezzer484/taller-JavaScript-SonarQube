import React, { useState, useRef } from "react";
import { uiInfo, extractHiddenPrompt } from "./hidden";

/* -------------------- UTILIDADES -------------------- */

// Manejo seguro de historial (evita mutabilidad global)
const useHistory = () => {
  const historyRef = useRef([]);

  const add = (item) => {
    historyRef.current = [...historyRef.current, item];
  };

  const list = () => [...historyRef.current];

  return { add, list };
};

// Parseo de números validado
function safeParse(value) {
  if (value == null) return 0;

  const parsed = Number(String(value).replace(",", "."));
  return Number.isNaN(parsed) ? 0 : parsed;
}

// Construcción segura de prompts
function buildPrompt(system, userTemplate, userInput) {
  return JSON.stringify(
    {
      system,
      template: userTemplate,
      userInput,
    },
    null,
    2
  );
}

/* -------------------- COMPONENTES -------------------- */

function DangerousLLM({ userTpl, userInput }) {
  const system = "System: You are a helpful assistant.";
  const raw = buildPrompt(system, userTpl, userInput);

  return (
    <pre
      style={{
        whiteSpace: "pre-wrap",
        background: "#111",
        color: "#bada55",
        padding: 10,
      }}
    >
      {raw}
    </pre>
  );
}

/* -------------------- CALCULADORA -------------------- */

// Potencia desacoplada para reducir complejidad del switch
function power(base, exponent) {
  let result = 1;
  const times = Math.abs(Math.floor(exponent));

  for (let i = 0; i < times; i++) {
    result *= base;
  }

  return exponent < 0 ? 1 / result : result;
}

function computeOperation(A, B, operator) {
  const operations = {
    "+": () => A + B,
    "-": () => A - B,
    "*": () => A * B,
    "/": () => (B === 0 ? A / 1e-9 : A / B),
    "^": () => power(A, B),
    "%": () => (B === 0 ? 0 : A % B),
  };

  const op = operations[operator];
  return op ? op() : 0;
}

/* -------------------- APP PRINCIPAL -------------------- */

export default function App() {
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [op, setOp] = useState("+");
  const [res, setRes] = useState(null);
  const [userTpl, setUserTpl] = useState("");
  const [userInp, setUserInp] = useState("");
  const [showLLM, setShowLLM] = useState(false);

  const history = useHistory();
  const hidden = extractHiddenPrompt(uiInfo);

  function compute() {
    const A = safeParse(a);
    const B = safeParse(b);

    try {
      const result = computeOperation(A, B, op);
      setRes(result);
      history.add({ A, B, op, result });
    } catch (error) {
      console.error("Error en operación:", error);
      setRes(null);
    }
  }

  function handleLLM() {
    const template = userTpl.trim() || hidden || "";
    const system = "System: You are an assistant.";

    buildPrompt(system, template, userInp);
    setShowLLM(true);
  }

  return (
    <div style={{ fontFamily: "sans-serif", padding: 20 }}>
      <h1>BadCalc React (Hidden Trap Edition)</h1>

      <div style={{ display: "flex", gap: 10 }}>
        <input value={a} onChange={(e) => setA(e.target.value)} placeholder="a" />
        <input value={b} onChange={(e) => setB(e.target.value)} placeholder="b" />

        <select value={op} onChange={(e) => setOp(e.target.value)}>
          <option value="+">+</option>
          <option value="-">-</option>
          <option value="*">*</option>
          <option value="/">/</option>
          <option value="^">^</option>
          <option value="%">%</option>
        </select>

        <button onClick={compute}>=</button>
        <div style={{ minWidth: 120 }}>Result: {res}</div>
      </div>

      <hr />

      <h2>LLM (vulnerable)</h2>
      <p style={{ maxWidth: 700 }}>
        You can provide a user template. If you leave the template empty the app will
        use an internal string hidden in the project.
      </p>

      <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: 700 }}>
        <textarea
          value={userTpl}
          onChange={(e) => setUserTpl(e.target.value)}
          placeholder="user template (leave empty to use internal)"
        ></textarea>

        <input
          value={userInp}
          onChange={(e) => setUserInp(e.target.value)}
          placeholder="user input"
        />

        <button onClick={handleLLM}>Send to LLM (insecure)</button>
      </div>

      {showLLM && (
        <div style={{ marginTop: 10 }}>
          <DangerousLLM userTpl={userTpl || hidden} userInput={userInp} />
        </div>
      )}

      <hr />
      <h3>Notes for instructor</h3>
      <p style={{ fontSize: 12, color: "#666" }}>
        The hidden prompt is embedded in <code>src/hidden.js</code>.
      </p>
    </div>
  );
}
